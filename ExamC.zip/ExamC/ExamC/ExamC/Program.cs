﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Text.RegularExpressions;
using System.IO;
namespace ExamC
{
    internal class Program
    { 
        static void Main(string[] args)
        {
            Dictionary dictionary = new Dictionary("English");
            bool isDone = false;
            while (!isDone)
            {
                int number;
                Console.WriteLine("0-exit");
                Console.WriteLine("1-Get");
                Console.WriteLine("2-Add");
                Console.WriteLine("3-Delete");
                Console.WriteLine("4-Replace");
                if(!int.TryParse(Console.ReadLine(),out number))
                {
                    number = -1;
                }
                switch (number)
                {
                    case 0:isDone = true;break;
                    case 1:
                        bool isDone1 = false;
                        while (!isDone1)
                        {
                            int number1;
                            Console.WriteLine("0-exit");
                            Console.WriteLine("1-GetWord");
                            Console.WriteLine("2-GetWordFile");

                            if (!int.TryParse(Console.ReadLine(), out number1))
                            {
                                number1 = -1;
                            }
                            switch (number1)
                            {
                                case 0:isDone1 = true;break;
                                case 1:
                                    Console.WriteLine("Write word:");
                                    string str = Console.ReadLine();
                                    Console.WriteLine($"Result={dictionary.GetWord(str)}");
                                    break;
                                case 2:
                                    Console.WriteLine("Write word:");
                                    string str1 = Console.ReadLine();
                                    dictionary.GetWordFile(str1);
                                    break;
                            }
                        }
                            break;
                    case 2:
                        bool isDone2 = false;
                        while (!isDone2)
                        {
                            int number1;
                            Console.WriteLine("0-exit");
                            Console.WriteLine("1-AddWord");
                            Console.WriteLine("2-AddWordOrValue");

                            if (!int.TryParse(Console.ReadLine(), out number1))
                            {
                                number1 = -1;
                            }
                            switch (number1)
                            {
                                case 0: isDone2 = true; break;
                                case 1:
                                    Console.WriteLine("Write word:");
                                    string str = Console.ReadLine();
                                    Console.WriteLine("Write value:");
                                    string strvalue = Console.ReadLine();
                                    if (!dictionary.AddWord(str, strvalue))
                                    {
                                        Console.WriteLine("Write not right word");
                                    }
                                    break;
                                case 2:
                                    Console.WriteLine("Write word:");
                                    string str1 = Console.ReadLine();
                                    Console.WriteLine("Write value:");
                                    string str1value = Console.ReadLine();
                                    if (!dictionary.AddWordOrValue(str1, str1value))
                                    {
                                        Console.WriteLine("Write not right value");
                                    }
                                    break;
                            }
                        }

                        break;
                    case 3:
                        bool isDone3 = false;
                        while (!isDone3)
                        {
                            int number1;
                            Console.WriteLine("0-exit");
                            Console.WriteLine("1-DeleteWord");
                            Console.WriteLine("2-DeleteValue");

                            if (!int.TryParse(Console.ReadLine(), out number1))
                            {
                                number1 = -1;
                            }
                            switch (number1)
                            {
                                case 0: isDone3 = true; break;
                                case 1:
                                    Console.WriteLine("Write word:");
                                    string str = Console.ReadLine();
                                    if (!dictionary.DeleteWord(str))
                                    {
                                        Console.WriteLine("Write not right word");
                                    }
                                    break;
                                case 2:
                                    Console.WriteLine("Write word:");
                                    string str1 = Console.ReadLine();
                                    Console.WriteLine("Write value:");
                                    string str1value = Console.ReadLine();
                                    if (!dictionary.DeleteValue(str1, str1value))
                                    {
                                        Console.WriteLine("Write not right value");
                                    }
                                    break;
                            }
                        }

                        break;
                    case 4:
                        bool isDone4 = false;
                        while (!isDone4)
                        {
                            int number1;
                            Console.WriteLine("0-exit");
                            Console.WriteLine("1-ReplaxeWord");
                            Console.WriteLine("2-ReplaceValue");

                            if (!int.TryParse(Console.ReadLine(), out number1))
                            {
                                number1 = -1;
                            }
                            switch (number1)
                            {
                                case 0: isDone4 = true; break;
                                case 1:
                                    Console.WriteLine("Write word:");
                                    string str = Console.ReadLine();
                                    Console.WriteLine("Write new Word");
                                    string strnew = Console.ReadLine();
                                    if (!dictionary.ReplaceWord(str,strnew))
                                    {
                                        Console.WriteLine("Write not right word");
                                    }
                                    break;
                                case 2:
                                    Console.WriteLine("Write word:");
                                    string str1 = Console.ReadLine();
                                    Console.WriteLine("Write value:");
                                    string str1value = Console.ReadLine();
                                    if (!dictionary.ReplaceValue(str1, str1value))
                                    {
                                        Console.WriteLine("Write not right value");
                                    }
                                    break;
                            }
                        }
                        break;
                }
            }
        }
    }
    class Dictionary:IDisposable
    {
        Hashtable hashtable = new Hashtable();
        Regex RegexKey = new Regex("");
        Regex RegexValue = new Regex("");
        int number;
        bool IsChanged = false;
        private bool disposedValue;
        string path = $@"{AppDomain.CurrentDomain.BaseDirectory}\dictionaries";
        void setRegex(string Language)
        {
            Regex Russia = new Regex("[а-я- ]+");
            Regex English = new Regex("[a-z- ]+");
            
            if (Language == "English")
            {
                number = 1;
                RegexKey = English;
                RegexValue = Russia;
            }
            if (Language == "Russia")
            {
                number = 2;
                RegexKey = Russia;
                RegexValue = English;
            }   
        }
        public Dictionary(string Language)
        {
            if (Language == "Russia" || Language == "English")
            {
                setRegex(Language);
                ReadFile();
            }
            else
            {
                throw new Exception();
            }
        }
        public bool AddWord(string _key,string _value)
        {
            string key = _key.Trim().ToLower();
            string value = _value.Trim().ToLower();
            if (!RegexKey.IsMatch(key) || !RegexValue.IsMatch(value)||hashtable.Contains(key))
            {
                return false;
            }
            IsChanged = true;
            hashtable.Add(key, value);
            return true;
        }
        public bool AddWordOrValue(string _key,string _value)
        {
            string key = _key.Trim().ToLower();
            string value = _value.Trim().ToLower();
            if (!hashtable.Contains(key))
            {
                return AddWord(_key, value);
            }
            string[]str= hashtable[key].ToString().Split(',');
            if (str.Contains(value))
            {
                return false;
            }
            IsChanged = true;
            hashtable[key] = hashtable[key] + "," + value;
            return true;
        }
        public bool ReplaceWord(string _key,string _newKey)
        {
            string key = _key.Trim().ToLower();
            string newKey = _newKey.Trim().ToLower();
            if (!hashtable.Contains(key)||!RegexKey.IsMatch(_newKey))
            {
                return false;
            }
            IsChanged = true;
            string str=hashtable[key].ToString();
            hashtable.Remove(key);
            hashtable.Add(newKey, str);
            return true;
        }
        public bool ReplaceValue(string _key,string _NewValue)
        {
            string key = _key.Trim().ToLower();
            string NewValue = _NewValue.Trim().ToLower();
            if (!hashtable.Contains(key)|| !RegexValue.IsMatch(NewValue))
            {
                return false;
            }
            IsChanged = true;
            hashtable[key] = NewValue;
            return true;
        }
        public bool DeleteWord(string _key)
        {
            string key = _key.Trim().ToLower();
            if (!hashtable.Contains(key))
            {
                return false;
            }
            IsChanged = true;
            hashtable.Remove(key);
            return true;
        }
        public bool DeleteValue(string _key,string _value)
        {
            string key = _key.Trim().ToLower();
            string value = _value.Trim().ToLower();
            if (!hashtable.Contains(key))
            {
                return false;
            }
            string[] str = hashtable[key].ToString().Split(',');
            if (!str.Contains(value)||str.Length<=1)
            {
                return false;
            }
            string str1="";
            for(int i = 0; i < str.Length; i++)
            {
                if(str[i]==value)
                {
                    str[i] = "";
                }
                str1 += str.ElementAt(i);
            }
            IsChanged = true;
            hashtable[key] = str1;
            return true;
        }
        public object GetWord(string _key)
        {
            string key = _key.Trim().ToLower();
            if (hashtable.Contains(key))
            {
                return hashtable[key];
            }
            return "";
        }
        public bool GetWordFile(string _key)
        {
            string key = _key.Trim().ToLower();
            if (!hashtable.Contains(key))
            {
                return false;
            }
            Directory.CreateDirectory($@"{path}\interpreter{number}");
            using(FileStream fs=new FileStream($@"{path}\interpreter{number}\{key}.txt",FileMode.OpenOrCreate,FileAccess.Write))
            {
                string str = key + "=" + hashtable[key] + ";";
                byte[] data = Encoding.UTF8.GetBytes(str);
                fs.Write(data, 0, data.Length);
            }
            return true;
        }
        void SetFile()
        {
            if (IsChanged)
            {
               
                using (FileStream fs = new FileStream($@"{path}\Dictionary{number}.txt", FileMode.Create, FileAccess.Write,FileShare.None))
                {
                    string str = "";
                    foreach (DictionaryEntry e in hashtable)
                    {
                        str += e.Key.ToString() + "=" + e.Value + ";";
                    }
                    byte[] data = Encoding.UTF8.GetBytes(str);
                    fs.Write(data, 0, data.Length);
                };
            }
        }
        void ReadFile()
        {
            Directory.CreateDirectory($@"{path}");
            using (FileStream fs=new FileStream($@"{path}\Dictionary{number}.txt", FileMode.OpenOrCreate, FileAccess.Read,FileShare.Read))
            {
                byte[] data = new byte[fs.Length];
                fs.Read(data, 0, data.Length);
                string str = Encoding.UTF8.GetString(data);
                if (string.IsNullOrEmpty(str))
                {
                    return;
                }
                string[] musStr = str.Split(';');
                for(int i = 0; i < musStr.Length; i++)
                {
                    if (!string.IsNullOrEmpty(musStr[i]))
                    {
                        string[] musStr1 = musStr[i].Split('=');
                        hashtable.Add(musStr1[0], musStr1[1]);
                    }
                }
            }
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                SetFile();
                if (disposing)
                {
                    hashtable.Clear();
                    RegexKey = null;
                    RegexValue = null;
                    // TODO: освободить управляемое состояние (управляемые объекты)
                }
                
                // TODO: освободить неуправляемые ресурсы (неуправляемые объекты) и переопределить метод завершения
                // TODO: установить значение NULL для больших полей
                disposedValue = true;
            }
        }

        // // TODO: переопределить метод завершения, только если "Dispose(bool disposing)" содержит код для освобождения неуправляемых ресурсов
         ~Dictionary()
         {
             // Не изменяйте этот код. Разместите код очистки в методе "Dispose(bool disposing)".
             Dispose(disposing: false);
         }

        public void Dispose()
        {
            // Не изменяйте этот код. Разместите код очистки в методе "Dispose(bool disposing)".
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
}
